import 'dart:ui';
import 'package:fbissalama/Widgets/SignIn/GlassSignIn.dart';
import 'package:fbissalama/Widgets/SignIn/background.dart';
import 'package:fbissalama/Widgets/SignIn/behavior.dart';
import 'package:flutter/material.dart';

class SignInScreen extends StatefulWidget {
  @override
  _SignInScreenState createState() => _SignInScreenState();
}

class _SignInScreenState extends State<SignInScreen> {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      body: ScrollConfiguration(
        behavior: MyBehavior(),
        child: SingleChildScrollView(
          child: SizedBox(
            height: size.height,
            child: Stack(
              children: [
                Background(),
                Center(
                  child: Column(
                    children: [
                      GlassSignIn(),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
