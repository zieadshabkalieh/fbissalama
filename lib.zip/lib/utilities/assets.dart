class AppAssets {
  static const busIcon = 'assets/bus_icon.png';
  static const backgroundLogin = 'assets/background_login.jpg';
  static const background3 = 'assets/background_image2.jpg';
  static const backgroundOtp = 'assets/otp.jpg';
  static const backgroundOtp2 = 'assets/otp2.png';
  static const googleicon = 'assets/google.svg';
  static const phoneicon = 'assets/phone.svg';
}
