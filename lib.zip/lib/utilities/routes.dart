class AppRoutes {
  static const String loginPage = '/';
  static const String splashScreenPage = '/splash';
  static const String MainHomePage = '/home';
}