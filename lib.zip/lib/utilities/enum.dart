enum AuthFormType{
  login,
  register,
}