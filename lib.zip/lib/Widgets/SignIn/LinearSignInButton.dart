import 'package:fbissalama/Screens/MainHomeScreen/MainHomeScreen.dart';
import 'package:fbissalama/Screens/OTPScreen/otp.dart';
import 'package:fbissalama/Services/auth.dart';
import 'package:fbissalama/Widgets/SignIn/CountryPicker.dart';
import 'package:fbissalama/Widgets/SignIn/DropDown.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart' as firebase_auth;
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';

class LinearSignInButton extends StatefulWidget {
  final TextEditingController number;
  final TextEditingController password;
  const LinearSignInButton({Key? key, required this.number, required this.password}) : super(key: key);

  @override
  State<LinearSignInButton> createState() => LinearSignInButtonState();
}

class LinearSignInButtonState extends State<LinearSignInButton> {
  firebase_auth.FirebaseAuth firebaseAuth = firebase_auth.FirebaseAuth.instance;

  bool circular = false;

  String smsCode = "";

  String verificationIdFinal = "";

  @override
  Widget build(BuildContext context) {
    return InkWell(
      splashColor: Colors.transparent,
      highlightColor: Colors.transparent,
      onTap: () async {
        setState(() {
          circular = true;
        });
        if (widget.number.text.isNotEmpty && widget.password.text.isNotEmpty) {
          try {
            // firebase_auth.UserCredential userCredential =
            // await firebaseAuth.signInWithEmailAndPassword(email: widget.number.text, password: widget.password.text);
            // print(userCredential.user!.email);
            // setState(() {
            //   circular = false;
            // });
            // print(userCredential);
            // Auth().signInWithEmailAndPassword(
            //     widget.email.text, widget.password.text);
            // Auth().signInwithPhoneNumber(verificationId, smsCode, context);
            // Auth().verifyPhoneNumber(CountryPickerState().dialCodeDigits +
            //     widget.number.text.substring(1), context, setData);
            // Auth().addUser(widget.number.text, DropdownState().dropdownValue,
            //     widget.password.text);
            //to enable phone verification
            if ("${widget.number.text[0]}" == "0") {
              // number.text = number.text.substring(1);

              Navigator.of(context).push(
                MaterialPageRoute(
                    builder: (context) =>
                        // MainHome()
                        OTP(
                      number:
                      CountryPickerState().dialCodeDigits +
                          widget.number.text.substring(1),
                    ),
                ),
              );
              setState(() {
                circular = false;
              });
            } else {
              HapticFeedback.lightImpact();
              Fluttertoast.showToast(
                msg: 'Invalid Phone Number',
              );
              setState(() {
                circular = false;
              });
            }
          } catch (e) {
            final snackbar = SnackBar(content: Text(e.toString()));
            ScaffoldMessenger.of(context).showSnackBar(snackbar);
            setState(() {
              circular = false;
            });}
        } else {
          HapticFeedback.lightImpact();
          Fluttertoast.showToast(
            msg: 'Please Fill All Gaps',
          );
          setState(() {
            circular = false;
          });
        }
      },
      child: Container(
        width: 150,
        height: 60,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          gradient: LinearGradient(
              colors: [Colors.white10, Colors.white54, Colors.white10]),
        ),
        child: Center(
          child: circular
              ? CircularProgressIndicator()
              : Text(
                  "Sign In",
                  style: GoogleFonts.adamina(
                    textStyle: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
        ),
      ),
    );
  }
  void setData(String verificationId) {
    setState(() {
      verificationIdFinal = verificationId;
    });
  }
}
