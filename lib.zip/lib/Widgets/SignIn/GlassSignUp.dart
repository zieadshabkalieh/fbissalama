import 'dart:ui';
import 'package:fbissalama/Screens/SignInScreen/SignInScreen.dart';
import 'package:fbissalama/Services/auth.dart';
import 'package:fbissalama/Widgets/SignIn/Buttons.dart';
import 'package:fbissalama/Widgets/SignIn/CountryPicker.dart';
import 'package:fbissalama/Widgets/SignIn/DropDown.dart';
import 'package:fbissalama/Widgets/SignIn/LinearSignUpButton.dart';
import 'package:fbissalama/Widgets/SignIn/TextFields.dart';
import 'package:fbissalama/utilities/assets.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';

class GlassSignUp extends StatefulWidget {
  const GlassSignUp({Key? key}) : super(key: key);

  @override
  State<GlassSignUp> createState() => _GlassSignUpState();
}

class _GlassSignUpState extends State<GlassSignUp> {
  final TextEditingController email = TextEditingController();

  final TextEditingController password = TextEditingController();

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return SingleChildScrollView(
      child: ClipRRect(
        borderRadius: BorderRadius.circular(30),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaY: 1, sigmaX: 1),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const SizedBox(
                height: 50,
              ),
              Padding(
                padding: EdgeInsets.only(
                  top: size.width / 30,
                  bottom: size.width / 30,
                ),
                child: Text(
                  'SIGN UP',
                  style: GoogleFonts.davidLibre(
                    textStyle: TextStyle(
                      fontSize: 40,
                      fontWeight: FontWeight.w600,
                      color: Colors.white.withOpacity(.8),
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: 20,
              ),
              InkWell(
                onTap: () async {
                  await Auth().googleSignIn(context);
                },
                child: Container(
                  width: MediaQuery.of(context).size.width - 60,
                  height: 60,
                  child: Card(
                    color: Colors.black,
                    elevation: 8,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                      side: BorderSide(
                        width: 1,
                        color: Colors.grey,
                      ),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SvgPicture.asset(
                          AppAssets.googleicon,
                          height: 25,
                          width: 25,
                        ),
                        SizedBox(
                          width: 15,
                        ),
                        Text(
                          "Continue with Google",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 17,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: 15,
              ),
          InkWell(
            onTap: () {
              // Navigator.push(context,
              //     MaterialPageRoute(builder: (builder) => PhoneAuthPage()));
            },
            child: Container(
              width: MediaQuery.of(context).size.width - 60,
              height: 60,
              child: Card(
                color: Colors.black,
                elevation: 8,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15),
                  side: BorderSide(
                    width: 1,
                    color: Colors.grey,
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SvgPicture.asset(
                      AppAssets.phoneicon,
                      height: 25,
                      width: 25,
                    ),
                    SizedBox(
                      width: 15,
                    ),
                    Text(
                      "Continue with Mobile",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 17,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          SizedBox(
            height: 18,),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.person_pin_circle_outlined,
                    color: Colors.white,
                    size: 30,
                  ),
                  SizedBox(
                    width: 15,
                  ),
                  Dropdown(),
                ],
              ),
              SizedBox(
                height: 10,
              ),
              MyTextField(size, email, false, Icon(Icons.email_outlined, color: Colors.white,),
                  'Email Address...', TextInputType.emailAddress),
              SizedBox(
                height: 20,
              ),
              MyTextField(
                  size,
                  password,
                  true,
                  Icon(Icons.lock_outline, color: Colors.white,),
                  // SizedBox(
                  //   width: 113,
                  //   child: Icon(
                  //     Icons.lock_outline,
                  //     color: Colors.white.withOpacity(.8),
                  //   ),
                  // ),
                  'Password...',
                  TextInputType.text),

              Row(
                children: [
                  SizedBox(
                    width: 15,
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      RichText(
                        text: TextSpan(
                          text: 'Already have an Account?',
                          style: GoogleFonts.adamina(
                            textStyle:
                            TextStyle(color: Colors.white, fontSize: 15),
                          ),
                          recognizer: TapGestureRecognizer()
                            ..onTap = () {
                              Navigator.of(context).push(
                                MaterialPageRoute(
                                    builder: (context) => SignInScreen()),
                              );
                            },
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              SizedBox(
                height: 10,
              ),
              LinearSignUpButton(email: email, password: password),
              SizedBox(
                height: 40,
              ),
              Center(
                  child: Text(
                    "Book your Journeys Online",
                    style: GoogleFonts.lobster(
                        textStyle: TextStyle(fontSize: 25, color: Colors.white)),
                  )),
            ],
          ),
        ),
      ),
    );
  }
}
