import 'dart:ui';
import 'package:fbissalama/Widgets/SignIn/GlassSignUp.dart';
import 'package:fbissalama/Widgets/SignIn/background.dart';
import 'package:fbissalama/Widgets/SignIn/behavior.dart';
import 'package:flutter/material.dart';

class SignUpScreen extends StatefulWidget {
  @override
  _SignUpScreenState createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      body: ScrollConfiguration(
        behavior: MyBehavior(),
        child: SingleChildScrollView(
          child: SizedBox(
            height: size.height,
            child: Stack(
              children: [
                Background(),
                Center(
                  child: Column(
                    children: [
                      GlassSignUp(),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
